import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-havings-form',
  templateUrl: './havings-form.component.html',
  styleUrls: ['./havings-form.component.scss'],
})
export class HavingsFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
